import { Vector3 } from "@babylonjs/core";
import type { GeospatialCamera } from "@babylonjs/core";
import type { GlobeViewState } from "../view.js";
import {
  ANCHOR_PAN_CHASE,
  clientToViewportCoords,
  computeScreenAnchorError,
  pickEllipsoidFromScreen,
  type ScreenAnchorError,
  type ScreenPickInput,
} from "./anchorPan.js";

import { DEFAULT_CAMERA_LIMITS, DEFAULT_GROUND_FOLLOW, type CameraLimits, type GroundFollow } from "../camera/cameraLimits.js";
import {
  geodeticToEcef,
  ecefToGeodetic,
  DEG_TO_RAD,
  RAD_TO_DEG,
  normalizeHeadingDeg,
  WGS84_A,
} from "../camera/cameraMath.js";

// ─── Camera State Limits ────────────────────────────────────────────

export {
  DEFAULT_CAMERA_LIMITS,
  DEFAULT_GROUND_FOLLOW,
  MAX_PITCH_DEG,
  MAX_ZOOM_METERS,
  MIN_PITCH_DEG,
  MIN_ZOOM_METERS,
  type CameraLimits,
  type GroundFollow,
} from "../camera/cameraLimits.js";
const MAX_ORBIT_HEIGHT_SMOOTHING_DELTA_MS = 100;

export interface OrbitTargetHeightOptions {
  resolveSurfaceHeightMeters: (latDeg: number, lonDeg: number) => number | null;
  initialOffsetMeters?: number;
}

// ─── Pitch Conversion ───────────────────────────────────────────────
//
// Public API convention (matches foss-earth / Cesium):
//   pitchDeg = 0   → looking at the horizon
//   pitchDeg = 90  → looking straight down at the surface
//
// Babylon GeospatialCamera convention:
//   pitch = 0      → looking straight down (toward planet centre)
//   pitch = π/2    → looking at the horizon
//
// Conversion: babylonPitch = (π/2) × (1 − pitchDeg / 90)

function babylonPitchToSurfacePitchDeg(babylonPitch: number): number {
  return 90 * (1 - babylonPitch / (Math.PI / 2));
}

function surfacePitchDegToBabylonPitch(pitchDeg: number): number {
  return (Math.PI / 2) * (1 - pitchDeg / 90);
}


// ─── Camera Controller ───────────────────────────────────────────────

/**
 * State-driven camera controller wrapping a Babylon `GeospatialCamera`.
 *
 * Maintains a canonical `GlobeViewState` (lat / lon / heading / pitch / zoom)
 * and provides two-way sync with the underlying Babylon camera so that all
 * input handlers can work on the canonical state rather than raw pointer deltas.
 */
export interface CameraControllerPorts {
  /** Shared monotonic host clock, milliseconds. */
  nowMs(): number;
  /** Host feature prevents globe grabbing over a pickable world point. */
  hasPickablePointAt(scene: ReturnType<GeospatialCamera["getScene"]>, x: number, y: number): boolean;
}

export class CameraController {
  private readonly camera: GeospatialCamera;
  private resolveSurfaceHeightMeters: ((latDeg: number, lonDeg: number) => number | null) | null = null;
  private orbitTargetOffsetMeters = 0;
  private smoothedSurfaceHeightMeters: number | null = null;
  private lastSurfaceHeightResolveMs: number | null = null;
  /** Fixed ellipsoid grab point from pointer down — the screen error segment starts here. */
  private anchorPanPoint: Vector3 | null = null;
  /** Client coords at pointer down — visual fallback when projection is stale. */
  private anchorPanDownClient: { x: number; y: number } | null = null;

  private limits: CameraLimits = DEFAULT_CAMERA_LIMITS;
  private groundFollow: GroundFollow = DEFAULT_GROUND_FOLLOW;
  /**
   * The nearest the camera may orbit after a view was handed back nearer
   * than the zoom limit, until it is out past the limit; null otherwise.
   */
  private zoomFloorMeters: number | null = null;

  constructor(camera: GeospatialCamera, private readonly ports: CameraControllerPorts) {
    this.camera = camera;
  }

  /** New limits apply at once: a view outside them moves inside. */
  setLimits(limits: CameraLimits): void {
    this.limits = {
      pitchDeg: { min: Math.min(limits.pitchDeg.min, limits.pitchDeg.max), max: Math.max(limits.pitchDeg.min, limits.pitchDeg.max) },
      zoomMeters: { min: Math.min(limits.zoomMeters.min, limits.zoomMeters.max), max: Math.max(limits.zoomMeters.min, limits.zoomMeters.max) },
    };
    if (this.zoomFloorMeters !== null && this.zoomFloorMeters >= this.limits.zoomMeters.min) this.zoomFloorMeters = null;
    this.camera.limits.radiusMin = this.zoomMinMeters();
    this.camera.limits.radiusMax = this.limits.zoomMeters.max;
    this.applyViewState(this.syncFromCamera(), this.getCurrentCenterHeightMeters());
  }

  /** The nearest the camera may orbit now: the zoom limit, or nearer after a view handed back nearer (`allowNearer`). */
  zoomMinMeters(): number {
    return this.zoomFloorMeters ?? this.limits.zoomMeters.min;
  }

  /**
   * Lets a view handed back nearer its orbit target than the zoom limit stay
   * as near as `nearestMeters`: it comes no nearer, and the limit returns
   * once it is out past it.
   */
  allowNearer(nearestMeters: number): void {
    this.zoomFloorMeters = nearestMeters < this.limits.zoomMeters.min ? Math.max(0, nearestMeters) : null;
    this.camera.limits.radiusMin = this.zoomMinMeters();
  }

  /** Where the orbit target sits over a point: the ground there and the target's offset, or null before the ground is known. */
  orbitTargetHeightAt(latDeg: number, lonDeg: number): number | null {
    const surface = this.resolveSurfaceHeightMeters?.(latDeg, lonDeg);
    return typeof surface === "number" ? surface + this.orbitTargetOffsetMeters : null;
  }

  /** Ground following starts from the orbit target's height now, rising or falling from there at its speed. */
  followGroundFromHere(): void {
    this.smoothedSurfaceHeightMeters = this.getCurrentCenterHeightMeters() - this.orbitTargetOffsetMeters;
    this.lastSurfaceHeightResolveMs = this.ports.nowMs();
  }

  getLimits(): CameraLimits {
    return this.limits;
  }

  /** How the orbit target follows the ground: from the next frame. */
  setGroundFollow(follow: GroundFollow): void {
    this.groundFollow = follow;
  }

  getGroundFollow(): GroundFollow {
    return this.groundFollow;
  }

  private clampPitchDeg(pitchDeg: number): number {
    return Math.max(this.limits.pitchDeg.min, Math.min(this.limits.pitchDeg.max, pitchDeg));
  }

  private clampZoomMeters(zoom: number): number {
    return Math.max(this.zoomMinMeters(), Math.min(this.limits.zoomMeters.max, zoom));
  }

  /** Out past the zoom limit, a view handed back near is under the limit again. */
  private relaxZoomFloor(zoom: number): void {
    if (this.zoomFloorMeters === null || zoom < this.limits.zoomMeters.min) return;
    this.zoomFloorMeters = null;
    this.camera.limits.radiusMin = this.zoomMinMeters();
  }

  configureOrbitTargetHeight(options: OrbitTargetHeightOptions | null): void {
    this.resolveSurfaceHeightMeters = options?.resolveSurfaceHeightMeters ?? null;
    this.orbitTargetOffsetMeters = Math.max(0, options?.initialOffsetMeters ?? 0);
    this.smoothedSurfaceHeightMeters = null;
    this.lastSurfaceHeightResolveMs = null;
    this.applyViewState(this.syncFromCamera());
  }

  private smoothSurfaceHeightMeters(targetHeightMeters: number): number {
    const now = this.ports.nowMs();
    if (this.smoothedSurfaceHeightMeters === null || this.lastSurfaceHeightResolveMs === null) {
      this.smoothedSurfaceHeightMeters = targetHeightMeters;
      this.lastSurfaceHeightResolveMs = now;
      return targetHeightMeters;
    }

    const deltaMs = Math.max(0, Math.min(MAX_ORBIT_HEIGHT_SMOOTHING_DELTA_MS, now - this.lastSurfaceHeightResolveMs));
    this.lastSurfaceHeightResolveMs = now;
    const maxStep = this.groundFollow.speedMetersPerSecond * (deltaMs / 1000);
    const delta = targetHeightMeters - this.smoothedSurfaceHeightMeters;
    if (Math.abs(delta) <= maxStep) {
      this.smoothedSurfaceHeightMeters = targetHeightMeters;
      return this.smoothedSurfaceHeightMeters;
    }

    this.smoothedSurfaceHeightMeters += Math.sign(delta) * maxStep;
    return this.smoothedSurfaceHeightMeters;
  }

  private resolveOrbitTargetHeightMeters(latDeg: number, lonDeg: number): number {
    const surfaceHeightMeters = this.smoothSurfaceHeightMeters(this.resolveSurfaceHeightMeters?.(latDeg, lonDeg) ?? 0);
    return surfaceHeightMeters + this.orbitTargetOffsetMeters;
  }

  private getCurrentCenterHeightMeters(): number {
    return ecefToGeodetic(this.camera.center.x, this.camera.center.y, this.camera.center.z).altMeters;
  }

  /**
   * Read the current `GlobeViewState` from the live camera properties.
   * This is the single source of truth — call this before every state mutation.
   */
  syncFromCamera(): GlobeViewState {
    const c = this.camera.center;
    const { latRad, lonRad } = ecefToGeodetic(c.x, c.y, c.z);

    const headingDeg = normalizeHeadingDeg(this.camera.yaw * RAD_TO_DEG);
    const pitchDeg = this.clampPitchDeg(babylonPitchToSurfacePitchDeg(this.camera.pitch));
    const zoomMeters = this.clampZoomMeters(this.camera.radius);

    return {
      latDeg: latRad * RAD_TO_DEG,
      lonDeg: lonRad * RAD_TO_DEG,
      headingDeg,
      pitchDeg,
      zoomMeters,
    };
  }

  /** Return the current view state (reads from live camera). */
  getViewState(): GlobeViewState {
    return this.syncFromCamera();
  }

  /**
   * Merge partial overrides into the current camera state and apply.
   * Only the supplied fields change; everything else is preserved.
   */
  setViewState(partial: Partial<GlobeViewState>): void {
    const next: GlobeViewState = { ...this.syncFromCamera(), ...partial };
    this.applyViewState(next);
  }

  /**
   * Write a complete `GlobeViewState` to the camera.
   * Clamps pitch and zoom to safe limits before applying.
   */
  applyViewState(state: GlobeViewState, targetHeightOverrideMeters?: number): void {
    const targetHeightMeters = targetHeightOverrideMeters
      ?? this.resolveOrbitTargetHeightMeters(state.latDeg, state.lonDeg);
    const { x, y, z } = geodeticToEcef(state.latDeg * DEG_TO_RAD, state.lonDeg * DEG_TO_RAD, targetHeightMeters);
    this.camera.center = new Vector3(x, y, z);
    this.camera.yaw = normalizeHeadingDeg(state.headingDeg) * DEG_TO_RAD;
    this.camera.pitch = surfacePitchDegToBabylonPitch(this.clampPitchDeg(state.pitchDeg));
    const zoom = this.clampZoomMeters(state.zoomMeters);
    this.camera.radius = zoom;
    this.relaxZoomFloor(zoom);
  }

  /**
   * Reset the camera to north-up orientation.
   * Preserves current lat / lon / zoom / pitch — only heading changes.
   */
  resetNorthUp(): void {
    this.setViewState({ headingDeg: 0 });
  }

  /**
   * Pan the camera by a screen-space pixel delta.
   * Translates the lat/lon anchor point while preserving heading, pitch, and zoom.
   * @param screenDxPx Positive = right (east when heading=0)
   * @param screenDyPx Positive = down (south when heading=0)
   * @param canvasHeight Canvas height in CSS pixels
   */
  panBy(screenDxPx: number, screenDyPx: number, canvasHeight: number): void {
    const state = this.syncFromCamera();
    // camera.fov is the vertical FOV in radians (inherited from Babylon Camera, default 0.8)
    const fovY = (this.camera as unknown as { fov: number }).fov ?? 0.8;
    const metersPerPixel = (2 * state.zoomMeters * Math.tan(fovY * 0.5)) / Math.max(canvasHeight, 1);

    const headingRad = state.headingDeg * DEG_TO_RAD;
    const latRad = state.latDeg * DEG_TO_RAD;
    const forwardM = -screenDyPx * metersPerPixel;
    const rightM = screenDxPx * metersPerPixel;
    const cosH = Math.cos(headingRad);
    const sinH = Math.sin(headingRad);
    const northM = forwardM * cosH - rightM * sinH;
    const eastM = forwardM * sinH + rightM * cosH;

    const cosLat = Math.max(Math.cos(latRad), 0.01);
    const latDeltaDeg = (northM / WGS84_A) * RAD_TO_DEG;
    const lonDeltaDeg = (eastM / (WGS84_A * cosLat)) * RAD_TO_DEG;

    const newLatDeg = Math.max(-89.999, Math.min(89.999, state.latDeg + latDeltaDeg));
    const newLonDeg = ((state.lonDeg + lonDeltaDeg + 180) % 360 + 360) % 360 - 180;
    this.applyViewState({ ...state, latDeg: newLatDeg, lonDeg: newLonDeg }, this.getCurrentCenterHeightMeters());
  }

  /**
   * Begin an anchor-based pan gesture by picking the globe point under the pointer.
   * Returns false when the ray misses the ellipsoid (sky / off-globe).
   */
  beginAnchorPan(pick: ScreenPickInput): boolean {
    const scene = this.camera.getScene();
    if (!scene) {
      this.anchorPanPoint = null;
      this.anchorPanDownClient = null;
      return false;
    }
    const { x, y } = clientToViewportCoords(pick.canvas, scene, pick.clientX, pick.clientY);
    if (this.ports.hasPickablePointAt(scene, x, y)) {
      this.anchorPanPoint = null;
      this.anchorPanDownClient = null;
      return false;
    }
    const hit = pickEllipsoidFromScreen(scene, this.camera, pick.canvas, pick.clientX, pick.clientY);
    if (!hit) {
      this.anchorPanPoint = null;
      this.anchorPanDownClient = null;
      return false;
    }
    this.anchorPanPoint = hit.clone();
    this.anchorPanDownClient = { x: pick.clientX, y: pick.clientY };
    return true;
  }

  /**
   * Continue an anchor-based pan: move orbit center lat/lon only (heading/pitch/zoom
   * unchanged) to shrink the screen-space line from the grab point to the cursor.
   */
  panAnchorTo(pick: ScreenPickInput, sensitivity = 1): boolean {
    if (!this.anchorPanPoint) {
      return false;
    }

    const scene = this.camera.getScene();
    if (!scene) {
      return false;
    }

    const error = computeScreenAnchorError(
      this.anchorPanPoint,
      pick.clientX,
      pick.clientY,
      scene,
      this.camera,
      pick.canvas,
      this.anchorPanDownClient ?? undefined,
    );
    if (!error || error.lengthPx < ANCHOR_PAN_CHASE.donePx) {
      return error !== null;
    }

    // Screen error is already in CSS pixels — apply directly to panBy (not the
    // legacy 0.1 movement gain used for inertial frame deltas).
    const chase = Math.min(
      ANCHOR_PAN_CHASE.maxFactor,
      Math.max(ANCHOR_PAN_CHASE.minFactor, error.lengthPx / ANCHOR_PAN_CHASE.fullChasePx),
    );
    const factor = sensitivity * chase;
    this.panBy(-error.dx * factor, -error.dy * factor, pick.canvas.clientHeight);
    return true;
  }

  /** End an anchor-based pan gesture. */
  endAnchorPan(): void {
    this.anchorPanPoint = null;
    this.anchorPanDownClient = null;
  }

  /** True while an anchor pan gesture is active. */
  isAnchorPanActive(): boolean {
    return this.anchorPanPoint !== null;
  }

  /** Screen-space error segment for the active grab point (debug / HUD). */
  getAnchorPanScreenError(pick: ScreenPickInput): ScreenAnchorError | null {
    if (!this.anchorPanPoint) {
      return null;
    }
    const scene = this.camera.getScene();
    if (!scene) {
      return null;
    }
    return computeScreenAnchorError(
      this.anchorPanPoint,
      pick.clientX,
      pick.clientY,
      scene,
      this.camera,
      pick.canvas,
      this.anchorPanDownClient ?? undefined,
    );
  }

  /**
   * Orbit the camera by a heading/pitch delta.
   * Moves around the current anchor point without changing lat/lon or zoom.
   * @param pitchDeltaDeg Positive = look more downward (toward surface)
   * @param headingDeltaDeg Positive = rotate clockwise (eastward)
   */
  orbitBy(pitchDeltaDeg: number, headingDeltaDeg: number): void {
    const DEADZONE_DEG = 0.02;
    const ep = Math.abs(pitchDeltaDeg) >= DEADZONE_DEG ? pitchDeltaDeg : 0;
    const eh = Math.abs(headingDeltaDeg) >= DEADZONE_DEG ? headingDeltaDeg : 0;
    if (ep === 0 && eh === 0) return;
    const state = this.syncFromCamera();
    this.applyViewState(
      {
        ...state,
        pitchDeg: this.clampPitchDeg(state.pitchDeg + ep),
        headingDeg: normalizeHeadingDeg(state.headingDeg + eh),
      },
      this.getCurrentCenterHeightMeters(),
    );
  }

  /**
   * Zoom by multiplying the orbit radius by `factor`.
   * factor < 1 = zoom in (move closer), factor > 1 = zoom out (move farther).
   */
  zoomBy(factor: number): void {
    if (!Number.isFinite(factor) || factor <= 0) {
      return;
    }

    const state = this.syncFromCamera();
    const requestedZoomMeters = state.zoomMeters * factor;

    if (requestedZoomMeters >= this.zoomMinMeters() || factor >= 1 || this.orbitTargetOffsetMeters <= 0) {
      this.setViewState({ zoomMeters: this.clampZoomMeters(requestedZoomMeters) });
      return;
    }

    const offsetStepMeters = Math.max(1, Math.abs(Math.log(factor)) * this.groundFollow.zoomStepMeters);
    this.orbitTargetOffsetMeters = Math.max(0, this.orbitTargetOffsetMeters - offsetStepMeters);
    this.applyViewState({ ...state, zoomMeters: this.zoomMinMeters() });
  }
}

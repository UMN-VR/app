# Contributing

Thank you for improving this project. Before opening a pull request, discuss material new features or large changes in an issue so the implementation fits the project's direction.

## Development

Follow this repository README for setup and checks. Use public exports, linked source, pinned packages or supported hybrid selections. Follow the owning language, strict types, formatting and lint rules; keep changes focused with meaningful tests. Do not add generated build output, credentials, API keys, vendor copies or unrelated formatting changes.

## Rights and licensing

By submitting a contribution, you confirm that you have the right to submit it under the repository's applicable licensing terms and that it does not include confidential, proprietary, or copied material without permission. Identify all third-party code, data, models, textures, sounds, fonts, and references in the pull request.

Creative assets need explicit provenance records and the owning repository asset-license guidance. Do not submit a model or reference merely because it is publicly downloadable.

## Pull requests

Explain the user-visible result, relevant tests, and any limitations. Update documentation when public behavior, setup, data sources, or licensing changes. Maintainers may request a smaller change, more tests, or provenance evidence before merge.

## Component responsibilities

Preserve human source history, licenses and asset provenance. The source map is
not replacement authorship. Publication and remote admission are coordinated.
Use public contracts and host injection; no feature or application deep imports.
Every setting has one existing tab/section home. Toolbar launchers toggle that
home, never a popup copy. Native controls keep their own keys; unused gestures
and keys continue to the host world input policy.
Use the assigned check window and incremental caches. Keep each run's log under
build and read existing evidence instead of repeating the suite.

## Commit attribution

You cannot have AI as a co-author, or your contributions will be rejected.

Do not add AI author, committer or co-author attribution. Branded AI contributor
credits put a vendor name in permanent contribution records and can imply
endorsement. This project treats that promotion as advertising and bans it in
contribution credits to keep contributor recognition independent of vendor
promotion and responsibility clear. The human submitting work remains
accountable for accuracy, review responses, provenance and rights. Required
license notices, factual tool documentation and legitimate human credits remain
valid.
